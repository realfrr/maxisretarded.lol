import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const approvedOnly = searchParams.get("approved") === "true"

    const testimonials = await db.testimonial.findMany({
      where: {
        ...(approvedOnly ? { approved: true } : {}),
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return NextResponse.json(testimonials)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch testimonials" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, role, imageUrl, stars, text } = body

    const session = await getServerSession(authOptions)
    const isAdmin = session?.user?.role === "ADMIN"

    const testimonial = await db.testimonial.create({
      data: {
        name,
        role,
        imageUrl,
        stars: Number.parseInt(stars),
        text,
        approved: isAdmin, // Auto-approve if admin is creating
      },
    })

    return NextResponse.json(testimonial, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create testimonial" }, { status: 500 })
  }
}

