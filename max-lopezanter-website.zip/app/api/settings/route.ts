import { NextResponse } from "next/server"

// In-memory settings storage
let siteSettings = {
  maintenanceMode: false,
  maintenanceMessage: "Website is getting updated, please wait!",
}

export async function GET() {
  return NextResponse.json(siteSettings)
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Update settings
    siteSettings = {
      ...siteSettings,
      ...data,
    }

    return NextResponse.json(siteSettings)
  } catch (error) {
    console.error("Settings API error:", error)
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
  }
}

