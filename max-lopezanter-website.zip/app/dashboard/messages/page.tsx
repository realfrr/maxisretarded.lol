"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Button } from "@/components/ui/button"
import { Check, Mail, MailOpen } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { formatDistanceToNow } from "date-fns"
import { Badge } from "@/components/ui/badge"

interface Message {
  id: string
  name: string
  email: string
  message: string
  read: boolean
  createdAt: string
}

export default function MessagesPage() {
  const { isAdmin } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [messages, setMessages] = useState<Message[]>([])
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      router.push("/dashboard")
      return
    }

    // Fetch messages
    const fetchMessages = async () => {
      try {
        const response = await fetch("/api/messages")
        if (response.ok) {
          const data = await response.json()
          setMessages(data)
        }
      } catch (error) {
        console.error("Failed to fetch messages:", error)
        toast({
          title: "Error",
          description: "Failed to load messages",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchMessages()
  }, [isAdmin, router, toast])

  const handleViewMessage = (message: Message) => {
    setSelectedMessage(message)
    setIsDialogOpen(true)

    // Mark as read if not already read
    if (!message.read) {
      handleMarkAsRead(message.id, false)
    }
  }

  const handleMarkAsRead = async (id: string, showToast = true) => {
    setIsProcessing(true)

    try {
      const response = await fetch(`/api/messages/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ read: true }),
      })

      if (response.ok) {
        setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read: true } : m)))

        if (selectedMessage?.id === id) {
          setSelectedMessage((prev) => (prev ? { ...prev, read: true } : null))
        }

        if (showToast) {
          toast({
            title: "Success",
            description: "Message marked as read",
          })
        }
      } else {
        throw new Error("Failed to update message")
      }
    } catch (error) {
      if (showToast) {
        toast({
          title: "Error",
          description: "Failed to mark message as read",
          variant: "destructive",
        })
      }
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDeleteMessage = async (id: string) => {
    setIsProcessing(true)

    try {
      const response = await fetch(`/api/messages/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setMessages((prev) => prev.filter((m) => m.id !== id))

        if (selectedMessage?.id === id) {
          setIsDialogOpen(false)
        }

        toast({
          title: "Success",
          description: "Message deleted successfully",
        })
      } else {
        throw new Error("Failed to delete message")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete message",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Messages" text="Manage contact form messages" />
        <div className="flex items-center justify-center h-64">
          <div className="spinner"></div>
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Messages" text="Manage contact form messages" />

      {messages.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 bg-muted/20 rounded-lg">
          <Mail className="h-10 w-10 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2">No messages yet</h3>
          <p className="text-muted-foreground">Messages from your contact form will appear here</p>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">Status</TableHead>
                <TableHead>From</TableHead>
                <TableHead>Message</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {messages.map((message) => (
                <TableRow key={message.id} className={message.read ? "" : "bg-muted/20"}>
                  <TableCell>
                    {message.read ? (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <MailOpen className="h-3 w-3" />
                        Read
                      </Badge>
                    ) : (
                      <Badge className="flex items-center gap-1 bg-primary">
                        <Mail className="h-3 w-3" />
                        New
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{message.name}</div>
                    <div className="text-sm text-muted-foreground">{message.email}</div>
                  </TableCell>
                  <TableCell>
                    <p className="truncate max-w-[300px]">{message.message}</p>
                  </TableCell>
                  <TableCell>{formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleViewMessage(message)}>
                        View
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Message Detail Dialog */}
      {selectedMessage && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Message from {selectedMessage.name}</DialogTitle>
              <DialogDescription>
                Received {formatDistanceToNow(new Date(selectedMessage.createdAt), { addSuffix: true })}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-right font-medium">From:</div>
                <div className="col-span-3">
                  {selectedMessage.name} ({selectedMessage.email})
                </div>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <div className="text-right font-medium">Message:</div>
                <div className="col-span-3 whitespace-pre-wrap">{selectedMessage.message}</div>
              </div>
            </div>
            <DialogFooter>
              {!selectedMessage.read && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handleMarkAsRead(selectedMessage.id)}
                  disabled={isProcessing}
                  className="mr-auto"
                >
                  <Check className="mr-2 h-4 w-4" />
                  Mark as Read
                </Button>
              )}
              <Button
                type="button"
                variant="destructive"
                onClick={() => handleDeleteMessage(selectedMessage.id)}
                disabled={isProcessing}
              >
                Delete
              </Button>
              <Button type="button" onClick={() => setIsDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </DashboardShell>
  )
}

