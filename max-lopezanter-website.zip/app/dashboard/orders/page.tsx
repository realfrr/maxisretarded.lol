"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Button } from "@/components/ui/button"
import { PlusCircle, Eye } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { formatDistanceToNow } from "date-fns"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Order {
  id: string
  buildType: string
  budget: number
  status: string
  description: string
  createdAt: string
  user?: {
    name: string
    email: string
  }
}

export default function OrdersPage() {
  const { user, isAdmin } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [orders, setOrders] = useState<Order[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [newOrder, setNewOrder] = useState({
    buildType: "gaming",
    budget: "",
    description: "",
  })

  useEffect(() => {
    // Fetch orders
    const fetchOrders = async () => {
      try {
        const response = await fetch("/api/orders")
        if (response.ok) {
          const data = await response.json()
          setOrders(data)
        }
      } catch (error) {
        console.error("Failed to fetch orders:", error)
        toast({
          title: "Error",
          description: "Failed to load orders",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchOrders()
  }, [toast])

  const handleAddOrder = () => {
    setNewOrder({
      buildType: "gaming",
      budget: "",
      description: "",
    })
    setIsDialogOpen(true)
  }

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order)
    setIsViewDialogOpen(true)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewOrder((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setNewOrder((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newOrder),
      })

      if (response.ok) {
        const savedOrder = await response.json()
        setOrders((prev) => [savedOrder, ...prev])
        setIsDialogOpen(false)
        toast({
          title: "Success",
          description: "Order submitted successfully",
        })
      } else {
        throw new Error("Failed to submit order")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit order",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleUpdateOrderStatus = async (id: string, status: string) => {
    try {
      const response = await fetch(`/api/orders/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)))

        if (selectedOrder?.id === id) {
          setSelectedOrder((prev) => (prev ? { ...prev, status } : null))
        }

        toast({
          title: "Success",
          description: "Order status updated successfully",
        })
      } else {
        throw new Error("Failed to update order status")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "PENDING":
        return <Badge variant="outline">Pending</Badge>
      case "IN_PROGRESS":
        return <Badge variant="secondary">In Progress</Badge>
      case "COMPLETED":
        return <Badge variant="default">Completed</Badge>
      case "CANCELLED":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Orders" text="Manage your PC build orders" />
        <div className="flex items-center justify-center h-64">
          <div className="spinner"></div>
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Orders" text="Manage your PC build orders">
        <Button onClick={handleAddOrder}>
          <PlusCircle className="mr-2 h-4 w-4" />
          New Order
        </Button>
      </DashboardHeader>

      {orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 bg-muted/20 rounded-lg">
          <h3 className="text-xl font-medium mb-2">No orders yet</h3>
          <p className="text-muted-foreground mb-4">Place your first order to get started</p>
          <Button onClick={handleAddOrder}>
            <PlusCircle className="mr-2 h-4 w-4" />
            New Order
          </Button>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Build Type</TableHead>
                <TableHead>Budget</TableHead>
                <TableHead>Status</TableHead>
                {isAdmin && <TableHead>Customer</TableHead>}
                <TableHead>Date</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium capitalize">{order.buildType}</TableCell>
                  <TableCell>${order.budget.toLocaleString()}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  {isAdmin && (
                    <TableCell>
                      {order.user?.name || "Unknown"}
                      <div className="text-xs text-muted-foreground">{order.user?.email}</div>
                    </TableCell>
                  )}
                  <TableCell>{formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleViewOrder(order)}>
                      <Eye className="h-4 w-4" />
                      <span className="sr-only">View</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* New Order Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>New PC Build Order</DialogTitle>
            <DialogDescription>Submit your requirements for a custom PC build</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmitOrder}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="buildType" className="text-right">
                  Build Type
                </Label>
                <Select value={newOrder.buildType} onValueChange={(value) => handleSelectChange("buildType", value)}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a build type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gaming">Gaming PC</SelectItem>
                    <SelectItem value="workstation">Workstation</SelectItem>
                    <SelectItem value="streaming">Streaming Setup</SelectItem>
                    <SelectItem value="custom">Custom Build</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="budget" className="text-right">
                  Budget ($)
                </Label>
                <Input
                  id="budget"
                  name="budget"
                  type="number"
                  value={newOrder.budget}
                  onChange={handleInputChange}
                  placeholder="2000"
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="description" className="text-right pt-2">
                  Requirements
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={newOrder.description}
                  onChange={handleInputChange}
                  placeholder="Describe your requirements, preferences, and any specific components you want..."
                  className="col-span-3"
                  rows={5}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? "Submitting..." : "Submit Order"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Order Dialog */}
      {selectedOrder && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Order Details</DialogTitle>
              <DialogDescription>
                Submitted {formatDistanceToNow(new Date(selectedOrder.createdAt), { addSuffix: true })}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-right font-medium">Build Type:</div>
                <div className="col-span-3 capitalize">{selectedOrder.buildType}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-right font-medium">Budget:</div>
                <div className="col-span-3">${selectedOrder.budget.toLocaleString()}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-right font-medium">Status:</div>
                <div className="col-span-3">{getStatusBadge(selectedOrder.status)}</div>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <div className="text-right font-medium pt-2">Requirements:</div>
                <div className="col-span-3 whitespace-pre-wrap">{selectedOrder.description}</div>
              </div>
            </div>
            {isAdmin && (
              <div className="border-t pt-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <div className="text-right font-medium">Update Status:</div>
                  <div className="col-span-3">
                    <Select
                      defaultValue={selectedOrder.status}
                      onValueChange={(value) => handleUpdateOrderStatus(selectedOrder.id, value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="PENDING">Pending</SelectItem>
                        <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                        <SelectItem value="COMPLETED">Completed</SelectItem>
                        <SelectItem value="CANCELLED">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button type="button" onClick={() => setIsViewDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </DashboardShell>
  )
}

