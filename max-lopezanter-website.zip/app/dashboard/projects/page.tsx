"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Button } from "@/components/ui/button"
import { PlusCircle, Pencil, Trash2, Star, StarOff } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Project {
  id: string
  title: string
  description: string
  imageUrl: string
  category: string
  specs: string[]
  featured: boolean
  createdAt: string
}

export default function ProjectsPage() {
  const { isAdmin } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [projects, setProjects] = useState<Project[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [currentProject, setCurrentProject] = useState<Partial<Project>>({
    title: "",
    description: "",
    imageUrl: "",
    category: "gaming",
    specs: [""],
    featured: false,
  })

  useEffect(() => {
    // Redirect if not admin
    if (!isAdmin) {
      router.push("/dashboard")
      return
    }

    // Fetch projects
    const fetchProjects = async () => {
      try {
        const response = await fetch("/api/projects")
        if (response.ok) {
          const data = await response.json()
          setProjects(data)
        }
      } catch (error) {
        console.error("Failed to fetch projects:", error)
        toast({
          title: "Error",
          description: "Failed to load projects",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchProjects()
  }, [isAdmin, router, toast])

  const handleAddProject = () => {
    setCurrentProject({
      title: "",
      description: "",
      imageUrl: "",
      category: "gaming",
      specs: [""],
      featured: false,
    })
    setIsDialogOpen(true)
  }

  const handleEditProject = (project: Project) => {
    setCurrentProject(project)
    setIsDialogOpen(true)
  }

  const handleDeleteProject = (project: Project) => {
    setCurrentProject(project)
    setIsDeleteDialogOpen(true)
  }

  const handleToggleFeatured = async (project: Project) => {
    try {
      const response = await fetch(`/api/projects/${project.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          featured: !project.featured,
        }),
      })

      if (response.ok) {
        setProjects((prev) => prev.map((p) => (p.id === project.id ? { ...p, featured: !p.featured } : p)))
        toast({
          title: "Success",
          description: `Project ${project.featured ? "unfeatured" : "featured"} successfully`,
        })
      } else {
        throw new Error("Failed to update project")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update project",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setCurrentProject((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setCurrentProject((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setCurrentProject((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSpecChange = (index: number, value: string) => {
    const newSpecs = [...(currentProject.specs || [])]
    newSpecs[index] = value
    setCurrentProject((prev) => ({ ...prev, specs: newSpecs }))
  }

  const addSpec = () => {
    setCurrentProject((prev) => ({
      ...prev,
      specs: [...(prev.specs || []), ""],
    }))
  }

  const removeSpec = (index: number) => {
    const newSpecs = [...(currentProject.specs || [])]
    newSpecs.splice(index, 1)
    setCurrentProject((prev) => ({ ...prev, specs: newSpecs }))
  }

  const handleSaveProject = async () => {
    setIsSaving(true)

    try {
      const method = currentProject.id ? "PATCH" : "POST"
      const url = currentProject.id ? `/api/projects/${currentProject.id}` : "/api/projects"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(currentProject),
      })

      if (response.ok) {
        const savedProject = await response.json()

        if (currentProject.id) {
          setProjects((prev) => prev.map((p) => (p.id === savedProject.id ? savedProject : p)))
        } else {
          setProjects((prev) => [...prev, savedProject])
        }

        setIsDialogOpen(false)
        toast({
          title: "Success",
          description: `Project ${currentProject.id ? "updated" : "created"} successfully`,
        })
      } else {
        throw new Error(`Failed to ${currentProject.id ? "update" : "create"} project`)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${currentProject.id ? "update" : "create"} project`,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteConfirm = async () => {
    if (!currentProject.id) return

    setIsSaving(true)

    try {
      const response = await fetch(`/api/projects/${currentProject.id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setProjects((prev) => prev.filter((p) => p.id !== currentProject.id))
        setIsDeleteDialogOpen(false)
        toast({
          title: "Success",
          description: "Project deleted successfully",
        })
      } else {
        throw new Error("Failed to delete project")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete project",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Projects" text="Manage your portfolio projects" />
        <div className="flex items-center justify-center h-64">
          <div className="spinner"></div>
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Projects" text="Manage your portfolio projects">
        <Button onClick={handleAddProject}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Project
        </Button>
      </DashboardHeader>

      {projects.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 bg-muted/20 rounded-lg">
          <h3 className="text-xl font-medium mb-2">No projects yet</h3>
          <p className="text-muted-foreground mb-4">Add your first project to showcase your work</p>
          <Button onClick={handleAddProject}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Project
          </Button>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Featured</TableHead>
                <TableHead className="w-[200px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projects.map((project) => (
                <TableRow key={project.id}>
                  <TableCell className="font-medium">{project.title}</TableCell>
                  <TableCell className="capitalize">{project.category}</TableCell>
                  <TableCell>
                    {project.featured ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                        Featured
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100">
                        Not Featured
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleToggleFeatured(project)}>
                        {project.featured ? <StarOff className="h-4 w-4" /> : <Star className="h-4 w-4" />}
                        <span className="sr-only">{project.featured ? "Unfeature" : "Feature"}</span>
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleEditProject(project)}>
                        <Pencil className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteProject(project)}>
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Add/Edit Project Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{currentProject.id ? "Edit Project" : "Add Project"}</DialogTitle>
            <DialogDescription>
              {currentProject.id ? "Update the details of your project" : "Add a new project to your portfolio"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="title" className="text-right">
                Title
              </Label>
              <Input
                id="title"
                name="title"
                value={currentProject.title}
                onChange={handleInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="category" className="text-right">
                Category
              </Label>
              <Select value={currentProject.category} onValueChange={(value) => handleSelectChange("category", value)}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gaming">Gaming</SelectItem>
                  <SelectItem value="workstation">Workstation</SelectItem>
                  <SelectItem value="streaming">Streaming</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="imageUrl" className="text-right">
                Image URL
              </Label>
              <Input
                id="imageUrl"
                name="imageUrl"
                value={currentProject.imageUrl}
                onChange={handleInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="description" className="text-right pt-2">
                Description
              </Label>
              <Textarea
                id="description"
                name="description"
                value={currentProject.description}
                onChange={handleInputChange}
                className="col-span-3"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right pt-2">Specifications</Label>
              <div className="col-span-3 space-y-2">
                {currentProject.specs?.map((spec, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={spec}
                      onChange={(e) => handleSpecChange(index, e.target.value)}
                      placeholder={`Specification ${index + 1}`}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      type="button"
                      onClick={() => removeSpec(index)}
                      disabled={currentProject.specs?.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" type="button" onClick={addSpec} className="mt-2">
                  Add Specification
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="featured" className="text-right">
                Featured
              </Label>
              <div className="col-span-3 flex items-center space-x-2">
                <Switch
                  id="featured"
                  checked={currentProject.featured}
                  onCheckedChange={(checked) => handleSwitchChange("featured", checked)}
                />
                <Label htmlFor="featured">Show in featured projects</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={handleSaveProject} disabled={isSaving}>
              {isSaving ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Delete Project</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this project? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" variant="destructive" onClick={handleDeleteConfirm} disabled={isSaving}>
              {isSaving ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}

