"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function SettingsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [maintenanceMode, setMaintenanceMode] = useState(false)
  const [maintenanceMessage, setMaintenanceMessage] = useState("Website is getting updated, please wait!")
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")

  // Fetch current settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings")
        if (response.ok) {
          const data = await response.json()
          setMaintenanceMode(data.maintenanceMode || false)
          setMaintenanceMessage(data.maintenanceMessage || "Website is getting updated, please wait!")
        }
      } catch (error) {
        console.error("Failed to fetch settings:", error)
      }
    }

    fetchSettings()
  }, [])

  // Check if user is authenticated and is admin
  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login")
    } else if (status === "authenticated" && session?.user?.role !== "ADMIN") {
      router.push("/")
    }
  }, [status, session, router])

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    setSaveMessage("")

    try {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          maintenanceMode,
          maintenanceMessage,
        }),
      })

      if (response.ok) {
        setSaveMessage("Settings saved successfully!")
      } else {
        setSaveMessage("Failed to save settings. Please try again.")
      }
    } catch (error) {
      console.error("Error saving settings:", error)
      setSaveMessage("An error occurred. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  if (status === "loading") {
    return <div className="p-8">Loading...</div>
  }

  if (status === "authenticated" && session?.user?.role === "ADMIN") {
    return (
      <div className="container mx-auto p-6">
        <h1 className="mb-6 text-2xl font-bold">Website Settings</h1>

        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="rounded-lg border p-6 shadow-sm">
            <h2 className="mb-4 text-xl font-semibold">Maintenance Mode</h2>

            <div className="mb-4">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={maintenanceMode}
                  onChange={(e) => setMaintenanceMode(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Enable Maintenance Mode</span>
              </label>
              <p className="mt-1 text-sm text-gray-500">
                When enabled, visitors will see a maintenance message instead of the website.
              </p>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Maintenance Message</label>
              <textarea
                value={maintenanceMessage}
                onChange={(e) => setMaintenanceMessage(e.target.value)}
                rows={3}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                placeholder="Enter the message visitors will see during maintenance"
              />
            </div>

            {maintenanceMode && (
              <div className="mt-4 rounded-md border border-gray-200 p-4">
                <h3 className="mb-2 text-sm font-medium">Preview:</h3>
                <div className="rounded-md bg-gray-50 p-4 text-center">
                  <h4 className="text-lg font-bold">Site Under Maintenance</h4>
                  <p className="mt-2 text-gray-600">{maintenanceMessage}</p>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-70"
            >
              {isSaving ? "Saving..." : "Save Settings"}
            </button>

            {saveMessage && (
              <p className={`text-sm ${saveMessage.includes("success") ? "text-green-600" : "text-red-600"}`}>
                {saveMessage}
              </p>
            )}
          </div>
        </form>
      </div>
    )
  }

  return null
}

