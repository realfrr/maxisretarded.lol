"use client"

import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { PortfolioSection } from "@/components/portfolio-section"
import { ServicesSection } from "@/components/services-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { useEffect, useState } from "react"
import { Testimonials } from "@/components/testimonials"
import { FaqSection } from "@/components/faq-section"
import { Spinner } from "@/components/ui/spinner"
import { useAuth } from "@/hooks/use-auth"

export default function Home() {
  const { user, isAdmin } = useAuth()
  const [isLoading, setIsLoading] = useState(true)
  const [settings, setSettings] = useState<any>(null)

  // Fetch site settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings")
        if (response.ok) {
          const data = await response.json()
          setSettings(data)
        }
      } catch (error) {
        console.error("Failed to fetch site settings:", error)
      }
    }

    fetchSettings()
  }, [])

  // Add smooth scrolling for anchor links
  useEffect(() => {
    // Preload hero image
    const preloadImage = new Image()
    preloadImage.src =
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_4595-CDTU4vaazkakLgkw24IbRZbBtyujnR.jpeg"
    preloadImage.onload = () => {
      // Simulate loading for a smoother initial experience
      setTimeout(() => {
        setIsLoading(false)
      }, 1000)
    }

    // Fallback in case image doesn't load
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2500)

    return () => {
      clearTimeout(timer)
    }
  }, [])

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="relative mb-6 flex justify-center">
            <Spinner size="lg" />
          </div>
          <h2 className="text-2xl font-bold gradient-text shimmer">Max Lopezanter</h2>
          <p className="text-muted-foreground mt-2 fade-in-up">Loading amazing PC builds...</p>
        </div>
      </div>
    )
  }

  // Check if site is in maintenance mode (admin only)
  if (settings?.maintenanceMode && !isAdmin) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center max-w-md p-6">
          <h2 className="text-2xl font-bold mb-4">Site Under Maintenance</h2>
          <p className="text-muted-foreground mb-6">
            {settings.maintenanceMessage ||
              "We're currently updating our website to bring you an even better experience. Please check back soon!"}
          </p>
          <p className="text-sm text-muted-foreground">
            If you're an administrator, please{" "}
            <a href="/login" className="text-primary hover:underline">
              log in
            </a>{" "}
            to access the dashboard.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection settings={settings} />
      <AboutSection settings={settings} />
      <PortfolioSection />
      <ServicesSection />
      <Testimonials />
      <FaqSection />
      <ContactSection settings={settings} />
      <Footer settings={settings} />
    </div>
  )
}

