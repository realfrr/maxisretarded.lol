// Simple client-side database using localStorage
type User = {
  id: string
  name: string
  email: string
  password: string // In a real app, this would be hashed
  role: "USER" | "ADMIN"
  createdAt: string
}

type SiteSettings = {
  maintenanceMode: boolean
  maintenanceMessage?: string
  heroTitle?: string
  heroSubtitle?: string
  aboutText?: string
  contactEmail?: string
  contactPhone?: string
  socialLinks?: { platform: string; url: string }[]
}

// Initialize with default admin user
const defaultUsers: User[] = [
  {
    id: "admin-1",
    name: "Admin",
    email: "crystalsfromdiscord@gmail.com",
    password: "adminfr", // In a real app, this would be hashed
    role: "ADMIN",
    createdAt: new Date().toISOString(),
  },
]

// Initialize with default settings
const defaultSettings: SiteSettings = {
  maintenanceMode: false,
  maintenanceMessage: "Website is getting updated, please wait!",
  heroTitle: "Custom PC Builder",
  heroSubtitle: "High-Performance Custom PCs Built for Your Needs",
}

// Simple client-side database
export const db = {
  // User methods
  getUsers: async (): Promise<User[]> => {
    if (typeof window === "undefined") return defaultUsers

    const users = localStorage.getItem("users")
    return users ? JSON.parse(users) : defaultUsers
  },

  getUserByEmail: async (email: string): Promise<User | null> => {
    const users = await db.getUsers()
    return users.find((user) => user.email === email) || null
  },

  createUser: async (userData: Omit<User, "id" | "createdAt">): Promise<User> => {
    const users = await db.getUsers()
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString(),
    }

    const updatedUsers = [...users, newUser]
    if (typeof window !== "undefined") {
      localStorage.setItem("users", JSON.stringify(updatedUsers))
    }

    return newUser
  },

  // Settings methods
  getSiteSettings: async (): Promise<SiteSettings> => {
    if (typeof window === "undefined") return defaultSettings

    const settings = localStorage.getItem("siteSettings")
    return settings ? JSON.parse(settings) : defaultSettings
  },

  updateSiteSettings: async (settings: Partial<SiteSettings>): Promise<SiteSettings> => {
    const currentSettings = await db.getSiteSettings()
    const updatedSettings = { ...currentSettings, ...settings }

    if (typeof window !== "undefined") {
      localStorage.setItem("siteSettings", JSON.stringify(updatedSettings))
    }

    return updatedSettings
  },

  // Other methods for messages, projects, etc. would be added here
}

