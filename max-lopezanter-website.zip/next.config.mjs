/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: [
      'images.unsplash.com',
      'v0.blob.com',
      'hebbkx1anhila5yf.public.blob.vercel-storage.com',
    ],
  },
}

export default nextConfig

