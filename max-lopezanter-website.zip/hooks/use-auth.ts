"use client"

import { useSession, signOut } from "next-auth/react"

export function useAuth() {
  const { data: session, status } = useSession()

  const isAuthenticated = !!session?.user
  const isAdmin = session?.user?.role === "ADMIN"
  const isLoading = status === "loading"

  const logout = async () => {
    await signOut({ callbackUrl: "/" })
  }

  return {
    user: session?.user,
    isAuthenticated,
    isAdmin,
    isLoading,
    logout,
  }
}

