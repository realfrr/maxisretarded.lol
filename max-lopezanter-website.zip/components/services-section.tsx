"use client"

import { useEffect, useRef } from "react"
import { Check, Cpu, Wrench, Zap, Gauge, PaintBucket, ShieldCheck } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("active")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".reveal")
    elements.forEach((el) => observer.observe(el))

    return () => {
      elements.forEach((el) => observer.unobserve(el))
    }
  }, [])

  return (
    <section id="services" ref={sectionRef} className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold mb-4 reveal">PC Building Services</h2>
          <p className="text-xl text-muted-foreground reveal">
            Professional PC building and optimization services tailored to your needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 stagger-children">
          <Card className="reveal card-hover">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Cpu className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Custom PC Building</CardTitle>
              <CardDescription>Tailored systems for your specific needs</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Personalized consultation and component selection</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>High-performance gaming and workstation builds</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Small form factor and silent PC options</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Complete system testing and benchmarking</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="reveal card-hover">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <PaintBucket className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Aesthetic Customization</CardTitle>
              <CardDescription>Make your PC visually stunning</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Custom water cooling loops and reservoirs</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Premium cable management and custom sleeving</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>RGB lighting design and synchronization</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Custom case modifications and themes</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="reveal card-hover">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Wrench className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Maintenance & Upgrades</CardTitle>
              <CardDescription>Keep your system running optimally</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Component upgrades and replacements</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>System cleaning and dust removal</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Thermal paste replacement and cooling optimization</span>
                </li>
                <li className="flex items-start">
                  <Check className="mr-2 text-primary shrink-0 mt-1" />
                  <span>Software updates and performance tuning</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="max-w-4xl mx-auto bg-card rounded-xl p-8 shadow-md reveal transform transition-all duration-500 hover:shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Ready to get your dream PC?</h3>
              <p className="text-muted-foreground mb-6">
                Whether you're looking for a high-end gaming rig, a professional workstation, or a system upgrade, I'm
                here to help you build the perfect PC tailored to your needs and budget.
              </p>
              <Button asChild size="lg" className="hover-lift pulse">
                <Link href="#contact">Get a Free Consultation</Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4 stagger-children">
              <div className="flex flex-col items-center text-center p-4 bg-secondary/50 rounded-lg hover-lift">
                <Gauge className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium">Performance Tuning</h4>
              </div>
              <div className="flex flex-col items-center text-center p-4 bg-secondary/50 rounded-lg hover-lift">
                <ShieldCheck className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium">1-Year Warranty</h4>
              </div>
              <div className="flex flex-col items-center text-center p-4 bg-secondary/50 rounded-lg hover-lift">
                <Zap className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium">Overclocking</h4>
              </div>
              <div className="flex flex-col items-center text-center p-4 bg-secondary/50 rounded-lg hover-lift">
                <Wrench className="h-8 w-8 text-primary mb-2" />
                <h4 className="font-medium">Ongoing Support</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

