"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Spinner } from "@/components/ui/spinner"

interface Project {
  id: string
  title: string
  description: string
  imageUrl: string
  category: string
  specs: string[]
  featured: boolean
}

export function PortfolioSection() {
  const [filter, setFilter] = useState("all")
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [projects, setProjects] = useState<Project[]>([])

  // Fetch projects from the API
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await fetch("/api/projects")
        if (response.ok) {
          const data = await response.json()
          setProjects(data)
        }
      } catch (error) {
        console.error("Failed to fetch projects:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProjects()
  }, [])

  // Simple filtering function
  const filteredProjects =
    filter === "all" ? projects : projects.filter((project) => project.category.toLowerCase() === filter)

  // Handle filter change
  const handleFilterChange = (newFilter: string) => {
    if (filter === newFilter) return

    setIsLoading(true)

    // Use setTimeout to create a visual loading state
    setTimeout(() => {
      setFilter(newFilter)
      setIsLoading(false)
    }, 600)
  }

  // Handle project selection
  const handleProjectSelect = (project: Project) => {
    setSelectedProject(project)
    setIsDialogOpen(true)
  }

  // If no projects are available yet, use fallback data
  const fallbackProjects = [
    {
      id: "gaming-beast",
      title: "Gaming Beast PC",
      description: "High-end gaming PC with custom water cooling and synchronized RGB lighting",
      imageUrl:
        "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Z2FtaW5nJTIwcGN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
      category: "gaming",
      specs: [
        "Intel Core i9-13900K",
        "NVIDIA RTX 4090 24GB",
        "64GB DDR5 6000MHz RAM",
        "2TB NVMe Gen4 SSD",
        "Custom Water Cooling Loop",
        "Lian Li O11 Dynamic XL Case",
        "1200W Platinum PSU",
      ],
      featured: true,
    },
    {
      id: "content-creator",
      title: "Content Creator Workstation",
      description: "Powerful workstation optimized for video editing and 3D rendering",
      imageUrl:
        "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y29tcHV0ZXIlMjB3b3Jrc3RhdGlvbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
      category: "workstation",
      specs: [
        "AMD Ryzen 9 7950X",
        "NVIDIA RTX 4080 16GB",
        "128GB DDR5 5600MHz RAM",
        "4TB NVMe Gen4 SSD RAID",
        "Noctua Cooling Solution",
        "Fractal Design Meshify 2 Case",
        "1000W Titanium PSU",
      ],
      featured: true,
    },
  ]

  const displayProjects = projects.length > 0 ? projects : fallbackProjects

  return (
    <section id="portfolio" className="py-24 relative overflow-hidden">
      {/* Background elements for animation */}
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl animate-float-slow"></div>
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl animate-float-slow-reverse"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-16 reveal">
          <h2 className="text-3xl font-bold mb-4">Featured PC Builds</h2>
          <p className="text-xl text-muted-foreground">A showcase of my recent custom PC builds and projects</p>

          <div className="mt-8 reveal-delay-2">
            <div className="inline-flex items-center justify-center bg-secondary/50 rounded-lg p-1 filter-container">
              <button
                onClick={() => handleFilterChange("all")}
                className={`px-4 py-2 rounded-md transition-all filter-button ${filter === "all" ? "active" : ""}`}
              >
                All
              </button>
              <button
                onClick={() => handleFilterChange("gaming")}
                className={`px-4 py-2 rounded-md transition-all filter-button ${filter === "gaming" ? "active" : ""}`}
              >
                Gaming
              </button>
              <button
                onClick={() => handleFilterChange("workstation")}
                className={`px-4 py-2 rounded-md transition-all filter-button ${
                  filter === "workstation" ? "active" : ""
                }`}
              >
                Workstation
              </button>
              <button
                onClick={() => handleFilterChange("streaming")}
                className={`px-4 py-2 rounded-md transition-all filter-button ${
                  filter === "streaming" ? "active" : ""
                }`}
              >
                Streaming
              </button>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <Spinner size="lg" />
            <span className="ml-4 text-lg fade-in">Loading projects...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 portfolio-grid">
            {filteredProjects.map((project, index) => (
              <div key={project.id} className={`portfolio-item animate-in-delay-${index}`}>
                <Card
                  className="overflow-hidden cursor-pointer hover:shadow-md transition-all h-full card-3d"
                  onClick={() => handleProjectSelect(project)}
                >
                  <div className="aspect-video bg-muted/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent z-0"></div>
                    <img
                      src={project.imageUrl || "/placeholder.svg?height=600&width=800"}
                      alt={project.title}
                      className="w-full h-full object-cover p-4 hover:scale-105 transition-transform duration-500 z-10 relative"
                      loading="lazy"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-muted-foreground mb-4">{project.description}</p>
                    <Button variant="outline" size="sm" className="hover-lift">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        )}

        {/* Project Details Dialog */}
        {selectedProject && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-3xl dialog-animation">
              <DialogHeader>
                <DialogTitle>{selectedProject.title}</DialogTitle>
                <DialogDescription>{selectedProject.description}</DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="rounded-lg overflow-hidden bg-card p-4 image-reveal">
                  <img
                    src={selectedProject.imageUrl || "/placeholder.svg?height=600&width=800"}
                    alt={selectedProject.title}
                    className="w-full h-auto object-cover"
                  />
                </div>

                <div className="specs-list">
                  <h4 className="text-lg font-semibold mb-4">Specifications</h4>
                  <ul className="space-y-2">
                    {selectedProject.specs.map((spec, i) => (
                      <li key={i} className="flex items-start spec-item" style={{ animationDelay: `${i * 100}ms` }}>
                        <span className="inline-block w-2 h-2 rounded-full bg-primary mt-1.5 mr-2"></span>
                        {spec}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6">
                    <Button asChild className="hover-lift pulse-on-hover">
                      <a href="#contact">Request Similar Build</a>
                    </Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </section>
  )
}

