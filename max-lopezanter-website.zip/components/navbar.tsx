"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X, Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/hooks/use-auth"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()
  const { isAuthenticated } = useAuth()

  // Wait for component to mount to avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const closeMenu = () => {
    setIsOpen(false)
  }

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/95 backdrop-blur-md border-b shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex-shrink-0">
            <Link href="/" className="text-xl md:text-2xl font-bold tracking-tight hover:opacity-80 transition-opacity">
              Max<span className="text-primary">.</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <Link
              href="#about"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              About
            </Link>
            <Link
              href="#portfolio"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              Portfolio
            </Link>
            <Link
              href="#services"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              Services
            </Link>
            <Link
              href="#testimonials"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              Testimonials
            </Link>
            <Link
              href="#faq"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              FAQ
            </Link>
            <Link
              href="#contact"
              className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
            >
              Contact
            </Link>
            {isAuthenticated && (
              <Link
                href="/dashboard"
                className="text-sm font-medium hover:text-primary transition-colors hover-lift inline-block"
              >
                Dashboard
              </Link>
            )}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
                className="hover-lift"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            )}

            <Button asChild className="hover-lift">
              <Link href="#contact">Get a Quote</Link>
            </Button>
          </div>

          <div className="flex md:hidden">
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="mr-2 hover-lift"
                aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            )}

            <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Toggle menu" className="hover-lift">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu with animation */}
      <div
        className={`md:hidden bg-background border-b overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="px-4 pt-2 pb-6 space-y-2">
          <Link
            href="#about"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            About
          </Link>
          <Link
            href="#portfolio"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            Portfolio
          </Link>
          <Link
            href="#services"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            Services
          </Link>
          <Link
            href="#testimonials"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            Testimonials
          </Link>
          <Link
            href="#faq"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            FAQ
          </Link>
          <Link
            href="#contact"
            className="block py-3 text-base font-medium hover:text-primary transition-colors"
            onClick={closeMenu}
          >
            Contact
          </Link>
          {isAuthenticated && (
            <Link
              href="/dashboard"
              className="block py-3 text-base font-medium hover:text-primary transition-colors"
              onClick={closeMenu}
            >
              Dashboard
            </Link>
          )}
          <div className="pt-2">
            <Button asChild className="w-full hover-lift">
              <Link href="#contact" onClick={closeMenu}>
                Get a Quote
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

