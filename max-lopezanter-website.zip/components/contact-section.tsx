"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Github, Linkedin, Mail, Twitter, Phone, MapPin, ExternalLink } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"

export function ContactSection({ settings }: { settings?: any }) {
  const { toast } = useToast()
  const { user } = useAuth()
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast({
          title: "Message sent!",
          description: "Thank you for your message. I'll get back to you soon.",
        })
        setFormData((prev) => ({ ...prev, message: "" }))
      } else {
        toast({
          title: "Error",
          description: "Failed to send message. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section id="contact" className="py-24 bg-grid relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute top-20 right-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-float-slow"></div>
      <div className="absolute bottom-20 left-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-float-slow-reverse"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div className="reveal">
                <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
                <p className="text-lg text-muted-foreground mb-8 max-w-md">
                  Ready to get your dream PC built? Have questions about components or upgrades? Reach out through any
                  of these channels and let's discuss your perfect build.
                </p>
              </div>

              <div className="space-y-6 stagger-children">
                <Card className="card-hover card-3d">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-4 shimmer">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Email</h3>
                        <p className="text-muted-foreground">
                          <a
                            href={`mailto:${settings?.contactEmail || "max@custompcbuilds.com"}`}
                            className="hover:text-primary transition-colors flex items-center hover-lift"
                          >
                            {settings?.contactEmail || "max@custompcbuilds.com"}
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-hover card-3d">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-4 shimmer">
                        <Phone className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Phone</h3>
                        <p className="text-muted-foreground">
                          <a
                            href={`tel:${settings?.contactPhone || "+1234567890"}`}
                            className="hover:text-primary transition-colors flex items-center hover-lift"
                          >
                            {settings?.contactPhone || "(123) 456-7890"}
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-hover card-3d">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-4 shimmer">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Location</h3>
                        <p className="text-muted-foreground">
                          {settings?.contactLocation || "Los Angeles, CA"}
                          <br />
                          Available for projects nationwide
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="reveal">
                <h3 className="text-xl font-semibold mb-4">Connect With Me</h3>
                <div className="flex space-x-4">
                  <a
                    href={settings?.socialTwitter || "https://twitter.com"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-background flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors hover-lift"
                    aria-label="Twitter"
                  >
                    <Twitter className="h-6 w-6" />
                  </a>
                  <a
                    href={settings?.socialGithub || "https://github.com"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-background flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors hover-lift"
                    aria-label="GitHub"
                  >
                    <Github className="h-6 w-6" />
                  </a>
                  <a
                    href={settings?.socialLinkedin || "https://linkedin.com"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-background flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors hover-lift"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="h-6 w-6" />
                  </a>
                  <a
                    href={`mailto:${settings?.contactEmail || "max@custompcbuilds.com"}`}
                    className="w-12 h-12 rounded-full bg-background flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors hover-lift"
                    aria-label="Email"
                  >
                    <Mail className="h-6 w-6" />
                  </a>
                </div>
              </div>
            </div>

            <div className="reveal">
              <Card className="shadow-lg transform transition-all duration-500 hover:shadow-xl overflow-hidden card-3d">
                <CardHeader className="bg-primary/5 border-b">
                  <CardTitle>Send a Message</CardTitle>
                  <CardDescription>Contact me directly to discuss your custom PC build</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Your name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Your email"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tell me about your project..."
                        rows={5}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full hover-lift pulse-on-hover" disabled={isSubmitting}>
                      {isSubmitting ? "Sending..." : "Send Message"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

