import { cn } from "@/lib/utils"

interface SpinnerProps {
  size?: "sm" | "md" | "lg"
  className?: string
}

export function Spinner({ size = "md", className }: SpinnerProps) {
  const sizeClasses = {
    sm: "w-4 h-4 border-2",
    md: "w-8 h-8 border-3",
    lg: "w-12 h-12 border-4",
  }

  return (
    <div
      className={cn("spinner", sizeClasses[size], className)}
      aria-label="Loading"
      style={{
        display: "inline-block",
        borderRadius: "50%",
        borderStyle: "solid",
        borderColor: "rgba(0, 0, 0, 0.1)",
        borderTopColor: "var(--primary-color, #10b981)",
        animation: "spin 0.8s linear infinite",
      }}
    >
      <span className="sr-only">Loading...</span>
    </div>
  )
}

