"use client"

import { useState } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const faqs = [
  {
    question: "What types of custom PCs do you build?",
    answer:
      "I specialize in building a wide range of custom PCs, including high-performance gaming rigs, content creation workstations, compact SFF builds, and professional workstations. Each build is tailored to the specific needs and budget of the client.",
  },
  {
    question: "How long does it take to build a custom PC?",
    answer:
      "The timeline varies depending on the complexity of the build and component availability. Typically, a standard build takes 1-2 weeks from order to delivery. More complex builds with custom water cooling or extensive modifications may take 2-4 weeks. I'll provide you with a specific timeline during our consultation.",
  },
  {
    question: "Do you offer warranties on your builds?",
    answer:
      "Yes, all my custom PC builds come with a 1-year warranty on labor and assembly. Individual components are covered by their respective manufacturer warranties, which I'll help you navigate if any issues arise. Extended warranty options are also available.",
  },
  {
    question: "Can I upgrade my PC in the future?",
    answer:
      "I design all builds with future upgradability in mind. During the build process, I'll explain potential upgrade paths and ensure your system has room for growth. I also offer upgrade services for existing builds, whether I built them originally or not.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "I accept various payment methods including credit/debit cards, PayPal, bank transfers, and installment plans through Affirm or Klarna. For custom builds, I typically require a 50% deposit to begin the build process, with the remaining balance due upon completion.",
  },
  {
    question: "Do you ship nationwide?",
    answer:
      "Yes, I ship custom PC builds nationwide with professional packaging to ensure safe delivery. For local clients in the Los Angeles area, I also offer personal delivery and setup services. International shipping is available on a case-by-case basis.",
  },
]

export function FaqSection() {
  const [openItem, setOpenItem] = useState<string | null>("item-0")

  return (
    <section id="faq" className="py-24 relative overflow-hidden">
      <div className="absolute -top-40 -left-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-16 reveal">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-muted-foreground">Find answers to common questions about custom PC builds</p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible value={openItem} onValueChange={setOpenItem} className="reveal">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b border-border">
                <AccordionTrigger className="text-lg font-medium hover:text-primary transition-colors py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-12 text-center reveal">
            <p className="text-lg mb-6">Still have questions? I'm here to help!</p>
            <Button asChild size="lg" className="hover-lift">
              <Link href="#contact">Contact Me</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

