"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"
import { LayoutDashboard, Settings, Package, Users, MessageSquare, Star, ShoppingCart } from "lucide-react"

interface DashboardNavProps {
  user: any
}

export function DashboardNav({ user }: DashboardNavProps) {
  const pathname = usePathname()
  const isAdmin = user?.role === "ADMIN"

  const routes = [
    {
      href: "/dashboard",
      label: "Overview",
      icon: <LayoutDashboard className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard",
    },
    {
      href: "/dashboard/orders",
      label: "Orders",
      icon: <ShoppingCart className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/orders",
    },
    {
      href: "/dashboard/profile",
      label: "Profile",
      icon: <Users className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/profile",
    },
  ]

  // Admin-only routes
  const adminRoutes = [
    {
      href: "/dashboard/projects",
      label: "Projects",
      icon: <Package className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/projects",
    },
    {
      href: "/dashboard/messages",
      label: "Messages",
      icon: <MessageSquare className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/messages",
    },
    {
      href: "/dashboard/testimonials",
      label: "Testimonials",
      icon: <Star className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/testimonials",
    },
    {
      href: "/dashboard/users",
      label: "Users",
      icon: <Users className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/users",
    },
    {
      href: "/dashboard/settings",
      label: "Settings",
      icon: <Settings className="mr-2 h-4 w-4" />,
      active: pathname === "/dashboard/settings",
    },
  ]

  const allRoutes = isAdmin ? [...routes, ...adminRoutes] : routes

  return (
    <nav className="grid items-start gap-2">
      {allRoutes.map((route) => (
        <Link
          key={route.href}
          href={route.href}
          className={cn(
            buttonVariants({ variant: "ghost" }),
            route.active ? "bg-muted hover:bg-muted" : "hover:bg-transparent hover:underline",
            "justify-start",
          )}
        >
          {route.icon}
          {route.label}
        </Link>
      ))}
    </nav>
  )
}

