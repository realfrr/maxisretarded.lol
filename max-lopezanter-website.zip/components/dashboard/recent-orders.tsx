import { formatDistanceToNow } from "date-fns"
import { Badge } from "@/components/ui/badge"

interface Order {
  id: string
  buildType: string
  budget: number
  status: string
  createdAt: Date
  user?: {
    name: string
    email: string
  }
}

interface RecentOrdersProps {
  orders: Order[]
}

export function RecentOrders({ orders }: RecentOrdersProps) {
  if (!orders || orders.length === 0) {
    return <div className="text-center py-4">No recent orders</div>
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium leading-none">{order.buildType}</p>
            <p className="text-sm text-muted-foreground">
              {order.user?.name || "Anonymous"} • ${order.budget}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant={order.status === "COMPLETED" ? "default" : order.status === "PENDING" ? "outline" : "secondary"}
            >
              {order.status.toLowerCase()}
            </Badge>
            <div className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(order.createdAt), {
                addSuffix: true,
              })}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

