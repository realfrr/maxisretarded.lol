import type React from "react"
import { UserNav } from "@/components/dashboard/user-nav"

interface DashboardHeaderProps {
  heading: string
  text?: string
  children?: React.ReactNode
  user?: any
}

export function DashboardHeader({ heading, text, children, user }: DashboardHeaderProps) {
  return (
    <div className="flex items-center justify-between px-2">
      <div className="grid gap-1">
        <h1 className="font-heading text-3xl md:text-4xl">{heading}</h1>
        {text && <p className="text-lg text-muted-foreground">{text}</p>}
      </div>
      <div className="flex items-center gap-4">
        {user && <UserNav user={user} />}
        {children}
      </div>
    </div>
  )
}

