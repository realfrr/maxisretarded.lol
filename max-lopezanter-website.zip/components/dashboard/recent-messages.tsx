"use client"

import { formatDistanceToNow } from "date-fns"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

interface Message {
  id: string
  name: string
  email: string
  message: string
  read: boolean
  createdAt: Date
}

interface RecentMessagesProps {
  messages: Message[]
}

export function RecentMessages({ messages }: RecentMessagesProps) {
  if (!messages || messages.length === 0) {
    return <div className="text-center py-4">No unread messages</div>
  }

  const markAsRead = async (id: string) => {
    // In a real app, this would call an API endpoint
    console.log(`Marking message ${id} as read`)
  }

  return (
    <div className="space-y-4">
      {messages.map((message) => (
        <div key={message.id} className="flex items-start justify-between border-b pb-4">
          <div className="space-y-1">
            <p className="text-sm font-medium leading-none">
              {message.name} <span className="text-muted-foreground">({message.email})</span>
            </p>
            <p className="text-sm text-muted-foreground line-clamp-2">{message.message}</p>
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(message.createdAt), {
                addSuffix: true,
              })}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => markAsRead(message.id)} className="ml-2 h-8 w-8 p-0">
            <Check className="h-4 w-4" />
            <span className="sr-only">Mark as read</span>
          </Button>
        </div>
      ))}
    </div>
  )
}

