"use client"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronDown, Cpu } from "lucide-react"

// Counter animation component
function AnimatedCounter({ end, duration = 2000, label }: { end: number; duration?: number; label: string }) {
  const [count, setCount] = useState(0)
  const countRef = useRef(0)
  const startTimeRef = useRef<number | null>(null)

  useEffect(() => {
    const animate = (timestamp: number) => {
      if (startTimeRef.current === null) {
        startTimeRef.current = timestamp
      }

      const progress = timestamp - startTimeRef.current
      const percentage = Math.min(progress / duration, 1)

      // Use easeOutQuad for smoother animation
      const easeOutQuad = (t: number) => t * (2 - t)
      const easedPercentage = easeOutQuad(percentage)

      const newCount = Math.floor(easedPercentage * end)

      if (newCount !== countRef.current) {
        countRef.current = newCount
        setCount(newCount)
      }

      if (percentage < 1) {
        requestAnimationFrame(animate)
      }
    }

    requestAnimationFrame(animate)

    return () => {
      startTimeRef.current = null
    }
  }, [end, duration])

  return (
    <div className="text-center">
      <div className="text-3xl font-bold gradient-text">
        {count}
        {end === 100 ? "%" : "+"}
      </div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  )
}

export function HeroSection({ settings }: { settings?: any }) {
  const [isVisible, setIsVisible] = useState(false)
  const [hasAnimated, setHasAnimated] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)
  const statsRef = useRef<HTMLDivElement>(null)
  const imageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)

    // Set up intersection observer for stats counter
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated) {
          setHasAnimated(true)
        }
      },
      { threshold: 0.5 },
    )

    if (statsRef.current) {
      observer.observe(statsRef.current)
    }

    // Add floating animation to image
    if (imageRef.current) {
      imageRef.current.classList.add("floating")
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current)
      }
    }
  }, [hasAnimated])

  const handleImageLoad = () => {
    setImageLoaded(true)
  }

  return (
    <section className="relative min-h-screen flex items-center pt-20 pb-16 overflow-hidden bg-dots">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className={`space-y-6 ${isVisible ? "animate-in" : "opacity-0"}`}>
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium animate-delay-1">
              <Cpu className="mr-2 h-4 w-4" />
              Custom PC Builder
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight animate-delay-2">
              {settings?.heroTitle || "Crafting"} <span className="gradient-text">Premium</span> Custom PCs
            </h1>

            <p className="text-xl text-muted-foreground max-w-lg animate-delay-3">
              {settings?.heroSubtitle ||
                "Creating high-performance custom computers with meticulous attention to detail, perfect cable management, and stunning aesthetics."}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4 animate-delay-4">
              <Button asChild size="lg" className="rounded-full hover-lift">
                <Link href="#portfolio">View My Builds</Link>
              </Button>

              <Button asChild variant="outline" size="lg" className="rounded-full hover-lift">
                <Link href="#contact">Get a Quote</Link>
              </Button>
            </div>

            <div ref={statsRef} className="grid grid-cols-3 gap-4 pt-8 animate-delay-5">
              {hasAnimated ? (
                <>
                  <AnimatedCounter end={5} label="Years Experience" />
                  <AnimatedCounter end={100} label="Custom Builds" />
                  <AnimatedCounter end={98} label="Client Satisfaction" />
                </>
              ) : (
                <>
                  <div className="text-center">
                    <div className="text-3xl font-bold gradient-text">0+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold gradient-text">0+</div>
                    <div className="text-sm text-muted-foreground">Custom Builds</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold gradient-text">0%</div>
                    <div className="text-sm text-muted-foreground">Client Satisfaction</div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div
            ref={imageRef}
            className={`relative ${isVisible ? "animate-in animate-delay-6" : "opacity-0"} ${imageLoaded ? "opacity-100" : "opacity-0"} transition-opacity duration-500`}
          >
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-green-500/20 rounded-full blur-3xl opacity-50 animate-pulse"></div>
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl glow">
              <div className="relative w-full aspect-[3/4]">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_4595-CDTU4vaazkakLgkw24IbRZbBtyujnR.jpeg"
                  alt="Max Lopezanter"
                  className="object-cover w-full h-full"
                  loading="eager"
                  onLoad={handleImageLoad}
                  style={{ opacity: 1 }}
                />
                {!imageLoaded && (
                  <div className="absolute inset-0 flex items-center justify-center bg-muted/20">
                    <div className="spinner"></div>
                  </div>
                )}
              </div>
            </div>

            <div
              className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl parallax"
              data-speed="30"
            ></div>
            <div
              className="absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl parallax"
              data-speed="20"
            ></div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <Link href="#about" aria-label="Scroll down">
          <ChevronDown className="h-8 w-8" />
        </Link>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  )
}

