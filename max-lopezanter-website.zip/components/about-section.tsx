"use client"

import { useEffect, useRef } from "react"
import { Cpu, Zap, PenToolIcon as Tool, Award } from "lucide-react"

export function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("active")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".reveal")
    elements.forEach((el) => observer.observe(el))

    return () => {
      elements.forEach((el) => observer.unobserve(el))
    }
  }, [])

  return (
    <section id="about" ref={sectionRef} className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold mb-4 reveal">About Max</h2>
          <p className="text-xl text-muted-foreground reveal">Custom PC Builder & Hardware Specialist</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 reveal">
            <p className="text-lg">
              I'm a professional PC builder with a passion for creating high-performance custom computers. With over 5
              years of experience in hardware selection, assembly, and optimization, I specialize in crafting systems
              tailored to each client's specific needs.
            </p>

            <p className="text-lg">
              Whether you're a competitive gamer seeking maximum FPS, a content creator requiring rendering power, or a
              professional needing a reliable workstation, I deliver custom-built PCs that exceed expectations in both
              performance and aesthetics.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4 stagger-children">
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>Premium Components</span>
              </div>
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>Custom Water Cooling</span>
              </div>
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>Cable Management</span>
              </div>
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>Overclocking</span>
              </div>
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>RGB Synchronization</span>
              </div>
              <div className="flex items-center hover-lift">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <span>Thermal Optimization</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 stagger-children">
            <div className="bg-card rounded-xl p-6 shadow-sm card-hover">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Cpu className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Custom Builds</h3>
              <p className="text-muted-foreground">
                Creating bespoke PCs optimized for gaming, content creation, or professional workloads.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-sm card-hover">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Performance</h3>
              <p className="text-muted-foreground">
                Maximizing system performance through careful component selection and optimization.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-sm card-hover">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Tool className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Maintenance</h3>
              <p className="text-muted-foreground">
                Providing ongoing support, upgrades, and maintenance to keep your system running optimally.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-sm card-hover">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Aesthetics</h3>
              <p className="text-muted-foreground">
                Designing visually stunning builds with perfect cable management and synchronized lighting.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

