export function MaintenanceMode({ message }: { message: string }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-background">
      <div className="text-center max-w-md p-6">
        <h2 className="text-2xl font-bold mb-4">Site Under Maintenance</h2>
        <p className="text-muted-foreground mb-6">
          {message ||
            "We're currently updating our website to bring you an even better experience. Please check back soon!"}
        </p>
        <p className="text-sm text-muted-foreground">
          If you're an administrator, please{" "}
          <a href="/login" className="text-primary hover:underline">
            log in
          </a>{" "}
          to access the dashboard.
        </p>
      </div>
    </div>
  )
}

