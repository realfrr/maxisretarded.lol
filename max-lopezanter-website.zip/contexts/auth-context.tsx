"use client"

import type React from "react"

import { createContext, useContext } from "react"
import { useSession, signOut } from "next-auth/react"

interface AuthContextType {
  isAuthenticated: boolean
  isAdmin: boolean
  isLoading: boolean
  user: any
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  isAdmin: false,
  isLoading: true,
  user: null,
  logout: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()

  const isAuthenticated = !!session?.user
  const isAdmin = session?.user?.role === "ADMIN"
  const isLoading = status === "loading"

  const logout = async () => {
    await signOut({ callbackUrl: "/" })
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isAdmin,
        isLoading,
        user: session?.user,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)

